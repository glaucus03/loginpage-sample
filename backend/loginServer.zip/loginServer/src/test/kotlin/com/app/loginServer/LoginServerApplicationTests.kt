package com.app.loginServer

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LoginServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
